"""
# @Author  : GengChuhan
# @Time    : 2023/10/7 15:11
# @Function:
# @Description:
"""

import os
import sys

from setuptools import find_packages, setup

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)

setup(
    name='py_kafka_sink_kafka_func',
    version='0.1',
    packages=find_packages(),
)