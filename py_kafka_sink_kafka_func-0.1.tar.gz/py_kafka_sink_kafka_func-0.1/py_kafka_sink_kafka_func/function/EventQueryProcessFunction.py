"""
# @Author  : GengChuhan
# @Time    : 2023/9/12 15:48
# @Function: 
# @Description:
"""
import datetime
import json
import time
import pytz

from py_kafka_sink_kafka_func.dto.EmergencyDto import EmergencyDto
from py_kafka_sink_kafka_func.utils import GJMGJdbcTemplate

"""
# @Author  : GengChuhan
# @Time    : 2023/9/12 15:48
# @Function: 
# @Description: 连接jdbc查询一小时数据
"""
def queryEventOnehour(ts):
    tz = pytz.timezone('Asia/Shanghai')
    dt = pytz.datetime.datetime.fromtimestamp(ts, tz)
    """
    str_dt=dt.strftime('%Y-%m-%d %H:')
    print(str_dt)
    startDate = str_dt+"00:00"
    endDate = str_dt+"59:59"
    """
    str_dt = dt.strftime('%Y-%m-%d')
    print(str_dt)
    startDate = str_dt + " 00:00:00"
    endDate = str_dt + " 23:59:59"
    # querySql = "select id, detection_time,sdetail_position,edetail_position,type,sdetail_position_id ,end_time,find_time,status,congestion_length from emergency WHERE detection_time between " + "'" + startDate + "'" + "and" + "'" + endDate + "'"; * /
    sql = "SELECT " + \
        "ec.id As type," + \
        "e.id," + \
        "e.detection_time," + \
        "e.sdetail_position," + \
        "e.edetail_position," + \
        "e.sdetail_position_id," + \
        "e.end_time," + \
        "e.find_time," + \
        "e.status," + \
        "e.congestion_length " + \
        "FROM " + \
        "(" + \
        "SELECT " + \
        "ec.id AS ecxatId," + \
        "e.* " + \
        "FROM " + \
        "(" + \
        "SELECT " + \
        "ec.id AS ecId," + \
        "e.type," + \
        "e.sub_type," + \
        "e.id," + \
        "e.detection_time," + \
        "e.sdetail_position," + \
        "e.edetail_position," + \
        "e.sdetail_position_id," + \
        "e.end_time," + \
        "e.find_time," + \
        "e.status," + \
        "e.congestion_length " + \
        "FROM " + \
        "emergency e " + \
        "LEFT JOIN emergency_category ec ON e.category = ec.CODE " + \
        "AND ( e.detection_time between " + "'" + startDate + "'" + "and" + "'" + endDate + "' ) " + \
        ") e," + \
        "emergency_category ec " + \
        "WHERE " + \
        "ec.parent_id = e.ecId " + \
        "AND ec.`code` = e.type " + \
        ") e," + \
        "emergency_category ec " + \
        "WHERE " + \
        "ec.parent_id = e.ecxatId " + \
        "AND ec.`code` = e.sub_type"
    return GJMGJdbcTemplate.select_all(sql)

class EventQueryResult:
    def __init__(self):
        self.id = None
        self.detection_time = None
        self.congestion_length = None
        self.find_time = None
        self.end_time = None
        self.status = None
        self.sdetail_position_id = None
        self.sdetail_position = None
        self.edetail_position = None
        self.type = None

def EventQueryProcessFunction(after,before,type_):
    after_js=json.loads(after)
    before_js = json.loads(before)
    if type_ == "delete":
            after_js=before_js
    maps = queryEventOnehour(after_js["detection_time"])
    result ={}
    for index,map in enumerate(maps):
        for obj in map:
            if(isinstance(map[obj], datetime.datetime)):
                map[obj]=int(time.mktime(map[obj].timetuple()))
                print(map[obj])
        result[str(index)]=map
    return json.dumps(result)
