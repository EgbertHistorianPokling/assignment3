"""
# @Author  : GengChuhan
# @Time    : 2023/9/12 15:48
# @Function: 
# @Description:
"""
import datetime
import json
import time
from _decimal import ROUND_HALF_UP
from decimal import Decimal

from py_kafka_sink_kafka_func.dto.EmergencyDto import EmergencyDto
from py_kafka_sink_kafka_func.utils import InfluxdbUtil, PsnChannelCodeUtils
from py_kafka_sink_kafka_func.utils.MeasureData import MeasureData


def create_measure_data(psn, date):
    measure_data = MeasureData()
    measure_data.set_psn(psn)
    measure_data.set_time(date)
    return measure_data


# @Author  : GengChuhan
# @Time    : 2023/9/12 15:48
# @Function:
# @Description:算事故数量

def event_num(psn, time, data, event_type, result, _dict):
    channel_code = _dict[EmergencyDto.EMERGENCY_TYPE_SHIGU_NUM][event_type]
    value=len(data)
    result_add_measure_data(psn,time,channel_code,value,result)

def result_add_measure_data(psn,time,channel_code,value,result):
    measure_data = create_measure_data(psn, time)
    measure_data.set_data({channel_code: value})
    result.append(measure_data)


# @Author  : GengChuhan
# @Time    : 2023/9/12 15:48
# @Function:
# @Description:算处置时长和拥堵距离


def dis_time_and_congestion_length(psn, time, data, event_type, result, _dict):
    time_interval = 0
    num = 0
    # 拥堵距离
    congestion_length = 0
    congestion_num = 0
    # 拥堵时长 分钟
    congestion_duration = 0
    congestion_duration_num = 0
    for emergencyDto in data:
        print(emergencyDto.get_find_time())
        if emergencyDto.get_status() == EmergencyDto().EMERGENCY_STATUS_END and emergencyDto.get_end_time() is not None:
            find_time = emergencyDto.get_find_time()
            end_time = emergencyDto.get_end_time()
            if end_time > find_time:
                # 某个事件的处置时长
                time_interval += end_time - find_time
                num += 1
            find_time = str(find_time * 1000000)
            end_time = str(end_time * 1000000)
            sql = "select count(\"100136\") as num from measure_data where  psn=" + "'" + psn + "'" + "\tand time >=" + find_time + "\tand time <=" + end_time + " and \"100136\" >60"
            array = InfluxdbUtil.query_influx_db(sql, "measure_data")
            if len(array) > 0:
                json_object = array[0]
                if json_object is not None:
                    result_congestion_duration = int(json_object["num"])
                    if result_congestion_duration is not None and result_congestion_duration != 0:
                        congestion_duration_num += 1
                        congestion_duration += result_congestion_duration
        if emergencyDto.get_congestion_length() is not None and emergencyDto.get_congestion_length() != "0":
            congestion_length += float(emergencyDto.get_congestion_length())
            congestion_num += 1

    if num != 0:
        channel_code = _dict[EmergencyDto.EMERGENCY_TYPE_SHIGU_DISTIME][event_type]
        value = float(Decimal(float(time_interval) / (1000 * 60 * num)).quantize(Decimal('0.00'),ROUND_HALF_UP))
        result_add_measure_data(psn,time,channel_code,value,result)

    # 各类叶子节点事故类型的拥堵距离  过滤为空的
    if congestion_num != 0:
        channel_code = _dict[EmergencyDto.EMERGENCY_TYPE_SHIGU_CONLENGTH][event_type]
        value = float(Decimal(float(congestion_length) / congestion_num).quantize(Decimal('0.00'),ROUND_HALF_UP))
        result_add_measure_data(psn,time,channel_code,value,result)

    # 各类叶子节点事故类型的拥堵时长
    if congestion_duration_num != 0:
        channel_code = _dict[EmergencyDto.EMERGENCY_TYPE_SHIGU_CONDURATION][event_type]
        value = float(Decimal(float(congestion_duration) / congestion_duration_num).quantize(Decimal('0.00'),ROUND_HALF_UP))
        result_add_measure_data(psn,time,channel_code,value,result)


class EventHandlerProcessFunction():
    def __init__(self,):
        self.sectionList = PsnChannelCodeUtils.query_section_list()
        self.unitCodeList = PsnChannelCodeUtils.query_unit_code_list()
        self.channelCodeMap = PsnChannelCodeUtils.query_event_type_and_channel_code()

    def get_section_list(self):
        return self.sectionList

    def set_section_list(self, section_list):
        self.sectionList = section_list

    def get_unit_code_list(self):
        return self.unitCodeList

    def set_unit_code_list(self, unit_code_list):
        self.unitCodeList = unit_code_list

    def get_channel_code_map(self):
        return self.channelCodeMap

    def set_channel_code_map(self, channel_code_map):
        self.channelCodeMap = channel_code_map

    def process_element(self, value):
        recombine_data = {}
        value=json.loads(value)
        for index in value:
            data = value[index]
            emergencyDto = EmergencyDto()
            emergencyDto.__dict__.update(data)
            if emergencyDto.get_type() not in recombine_data:
                emergency_dtos = []
            else:
                emergency_dtos = recombine_data[emergencyDto.get_type()]
            emergency_dtos.append(emergencyDto)
            recombine_data[emergencyDto.get_type()] = emergency_dtos
        print(recombine_data)
        result = []
        for _type in recombine_data.keys():
            recombine_data_psn = {}
            # 获取某个事件类型的事件集合
            emergency_dtos = recombine_data[_type]
            for emergencyDto in emergency_dtos:
                mileage = float(0)
                head = ""
                for unitCode in self.unitCodeList:
                    if emergencyDto.get_sdetail_position_id() == unitCode['id']:
                        mileage = unitCode['mileageValue']
                        head = unitCode['position']
                        break
                for i in range(len(self.sectionList)):
                    map = self.sectionList[i]
                    start_mileage_value = float(Decimal(map['startMileageValue']))
                    end_mileage_value = float(Decimal(map['endMileageValue']))
                    if map["position"] == head:
                        if mileage >= start_mileage_value and mileage < end_mileage_value or mileage >= end_mileage_value and mileage < start_mileage_value:
                            if map["psn"] not in recombine_data_psn:
                                emergency_dto_list_psn = []
                            else:
                                emergency_dto_list_psn = recombine_data_psn[map["psn"]]
                            emergency_dto_list_psn.append(emergencyDto)
                            recombine_data_psn[map["psn"]] = emergency_dto_list_psn
                            break
            # 同一个psn分区筛选出来的集合
            for psn in recombine_data_psn.keys():
                data = recombine_data_psn[psn]
                dt = data[0].get_detection_time()
                dt=datetime.datetime.fromtimestamp(dt)
                str_dt = dt.strftime('%Y-%m-%d')
                influx_time = str_dt + " 00:00:00"
                print(psn, influx_time, data, _type, result, self.channelCodeMap)
                print(data[0].__dict__)
                # 各类叶子节点事故类型的事故数量
                event_num(psn, influx_time, data, str(_type), result, self.channelCodeMap)
                # 各类叶子节点事故类型的平均处置时长  结束的
                dis_time_and_congestion_length(psn, influx_time, data, _type, result, self.channelCodeMap)
        
        # 封装influxdb对象
        """for measureData in result:
            collector.collect(new InfluxDBPoint("measure_data", measureData.getTime(), MapUtils.newHashMap("psn", measureData.getPsn() + ""), measureData.getData()));
        """
        print(result)
        rs={}
        for index, value in enumerate(result):
            rs[str(index)] = value.__dict__
        print(rs)
        return rs
