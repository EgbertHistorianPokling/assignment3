"""
# @Author  : GengChuhan
# @Time    : 2023/9/12 15:47
# @Function: 
# @Description:
"""


class EmergencyDto:
    ATTRIBUTE_TIME = "time"
    EMERGENCY_STATUS_END = "20"

    # 统计指标类型
    # 事故数量
    EMERGENCY_TYPE_SHIGU_NUM = "shigu_num"

    # 事故处置时长
    EMERGENCY_TYPE_SHIGU_DISTIME = "shigu_distime"

    # 事故拥堵距离
    EMERGENCY_TYPE_SHIGU_CONLENGTH = "shigu_conlength"

    # 事故拥堵时长
    EMERGENCY_TYPE_SHIGU_CONDURATION = "shigu_conduration"

    def __init__(self):
        self.id = None
        self.detection_time = None
        self.congestion_length = None
        self.find_time = None
        self.end_time = None
        self.status = None
        self.sdetail_position_id = None
        self.sdetail_position = None
        self.edetail_position = None
        self.type = None

    def get_id(self):
        return self.id

    def set_id(self, id):
        self.id = id

    def get_detection_time(self):
        return self.detection_time

    def set_detection_time(self, detection_time):
        self.detection_time = detection_time

    def get_congestion_length(self):
        return self.congestion_length

    def set_congestion_length(self, congestion_length):
        self.congestion_length = congestion_length

    def get_find_time(self):
        return self.find_time

    def set_find_time(self, find_time):
        self.find_time = find_time

    def get_end_time(self):
        return self.end_time

    def set_end_time(self, end_time):
        self.end_time = end_time

    def get_status(self):
        return self.status

    def set_status(self, status):
        self.status = status

    def get_sdetail_position_id(self):
        return self.sdetail_position_id

    def set_sdetail_position_id(self, sdetail_position_id):
        self.sdetail_position_id = sdetail_position_id

    def get_sdetail_position(self):
        return self.sdetail_position

    def set_sdetail_position(self, sdetail_position):
        self.sdetail_position = sdetail_position

    def get_edetail_position(self):
        return self.edetail_position

    def set_edetail_position(self, edetail_position):
        self.edetail_position = edetail_position

    def get_type(self):
        return self.type

    def set_type(self, type):
        self.type = type
