"""
# @Author  : GengChuhan
# @Time    : 2023/9/12 15:48
# @Function: 
# @Description:
"""


class UnitCodeDto:

    def __init__(self):
        self.id = None
        self.mileage_value = None
        self.position = None

    def get_id(self):
        return self.id

    def set_id(self,id):
        self.id = id

    def get_mileage_value(self):
        return self.mileage_value

    def set_mileage_value(self,mileage_value):
        self.mileage_value = mileage_value

    def get_position(self):
        return self.position

    def set_position(self, position):
        self.position = position
