"""
# @Author  : GengChuhan
# @Time    : 2023/9/12 15:49
# @Function: 
# @Description:
"""
from _decimal import Decimal

from py_kafka_sink_kafka_func.utils.InfluxDBConnect import InfluxDBConnect


def query_influx_db(query_sql, table_type):
    influxDB = InfluxDBConnect()
    result = influxDB.query(query_sql)
    influx_data_list = list(result.get_points(measurement=table_type))
    return influx_data_list


def get_influx_data(result, table_type):
    influx_data_list = None
    if result:
        influx_data_list = []
        series = result['series']
        if series and len(series) > 0:
            for serie in series:
                values = serie['value']
                result_list = get_influx_data_and_build(values, serie, table_type)
                influx_data_list.extend(result_list)
    return influx_data_list

def get_influx_data_and_build(values, serie, table_type):
    influx_data_list = []
    influx_cloumns = serie['coloumns']
    influx_tags = serie['tags']
    build_maps=None
    if values.size() > 0:
        for i in range(values.size()):
            build_maps = {}
            if influx_tags:
                for entry in influx_tags.entrySet():
                    entry_key = entry.keys()
                    if "tag_" in entry_key:
                        entry_key = entry_key[:4]
                    build_maps[entry_key]=entry['value']
            influx_Obj = values[i]
            for j in range(len(influx_Obj)):
                build_maps_key = influx_cloumns[j]
                if build_maps_key=="time":
                    if table_type=="normal":
                        bd = Decimal(influx_Obj[j])
                        build_maps["timestamp"]=str(bd)
                    elif table_type=="polymerize":
                        #  build_maps.put("timestamp",DateUtil.datetoStampAndAddMinute(String.valueOf(influx_Obj[j])));
                        pass
                else:
                    if "tag_" in build_maps_key:
                        build_maps_key = build_maps_key[:4]
                    build_maps[build_maps_key]=influx_Obj[j]
            influx_data_list.append(build_maps)
    return influx_data_list

