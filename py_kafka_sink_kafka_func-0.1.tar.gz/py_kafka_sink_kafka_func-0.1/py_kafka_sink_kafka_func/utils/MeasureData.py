class MeasureData:
    def __init__(self):
        self.data = None
        self.time = None
        self.psn = None

    def set_psn(self, psn):
        self.psn = psn

    def get_psn(self):
        return self.psn
    
    def set_time(self, time):
        self.time = time

    def get_time(self):
        return self.time
    
    def set_data(self, data):
        self.data = data

    def get_data(self):
        return self.data
