"""
# @Author  : GengChuhan
# @Time    : 2023/9/12 15:50
# @Function: 
# @Description:
"""

import json

from py_kafka_sink_kafka_func.utils import GJMGJdbcTemplate


def query_event_type_and_channel_code():
    dicts = GJMGJdbcTemplate.select_all(
        "select  type,event_type_id,channel_code  from  emergency_type_relation_channel")
    result={}
    for _dict in dicts:
        if _dict["type"] in result:
            _type=result[_dict["type"]]
        else:
            _type={}
        _type[str(_dict["event_type_id"])]=_dict["channel_code"]
        result[str(_dict["type"])]=_type
    return result


"""
# @author: GengChuhan
# @date: 2023/9/12 15:50
# @description:jdbc 百米段的设备psn
"""


def query_section_list():
    sql = " SELECT SUBSTRING(start_mileage,1,2) as position, start_mileage, end_mileage, psn, SUBSTRING(REPLACE(start_mileage,\"+\",\"\"),3) as startMileageValue, SUBSTRING(REPLACE(end_mileage,\"+\",\"\"),3) as endMileageValue from device where device_type_id=145 "
    dicts = GJMGJdbcTemplate.select_all(sql)
    return dicts


"""
# @author: GengChuhan
# @date: 2023/9/12 15:50
# @description:jdbc 事件里程号
"""


def query_unit_code_list():
    sql = "SELECT\tid,\tmileage_value AS mileageValue,\tposition \n" + \
          "FROM\n" + \
          "\tunit_code \n" + \
          "WHERE\n" + \
          "\ttype = 'mileage_number'"
    dicts = GJMGJdbcTemplate.select_all(sql)
    return dicts
