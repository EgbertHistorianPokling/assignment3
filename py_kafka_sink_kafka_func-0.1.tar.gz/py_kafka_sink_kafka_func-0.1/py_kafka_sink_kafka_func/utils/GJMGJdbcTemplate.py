"""
# @Author  : GengChuhan
# @Time    : 2023/9/12 15:49
# @Function: 
# @Description:
"""

import time
import pymysql

from py_kafka_sink_kafka_func.utils.PropConfig import PropConfig

pro_config = PropConfig()

url = pro_config.get_jdbc_url()
username = pro_config.get_mysql_user_name()
password = pro_config.get_mysql_password()
host = pro_config.get_mysql_host()
port = int(pro_config.get_mysql_port())
database = pro_config.get_mysql_database()

# driver = PropConfig.mysqlDriver

def get_connection():
    conn = None
    # conn = pymysql.connect(host=host, user=username, password=password, port=port)
    try:
        conn = pymysql.connect(host=host, user=username, password=password, database=database, port=port)
        print('mysql链接')
    except:
        print('获得链接失败!')
    return conn



def select_all(querysql):
    start_time = int(round(time.perf_counter() * 1000))  # current_time_millis
    conn = get_connection()
    cursor = conn.cursor()
    row_count = cursor.execute(querysql)
    datas = cursor.fetchall()
    description = cursor.description
    column_count = len(description)
    column_label = []

    for i in range(column_count):
        column_label.append(description[i][0])

    lists = []

    for data in datas:
        data_dict = {}
        for i in range(column_count):
            if data[i] is None or data[i] == "":
                data_dict[column_label[i]] = ""
            else:
                data_dict[column_label[i]] = data[i]
        lists.append(data_dict)

    print(" 执行成功一次,总使用时间：" + str(int(round(time.perf_counter() * 1000)) - start_time) + "ms")
    return lists
