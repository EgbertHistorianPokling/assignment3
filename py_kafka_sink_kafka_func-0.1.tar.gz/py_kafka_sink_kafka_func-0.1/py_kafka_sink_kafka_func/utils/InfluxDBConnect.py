"""
# @Author  : GengChuhan
# @Time    : 2023/9/12 15:49
# @Function: 
# @Description:
"""


from influxdb import InfluxDBClient

from py_kafka_sink_kafka_func.utils.PropConfig import PropConfig


class InfluxDBConnect:
    def __init__(self):
        self.username = PropConfig().get_influx_db_username()
        self.password = PropConfig().get_influx_db_password()
        self.openurl = PropConfig().get_influx_db_url()
        self.database = PropConfig().get_influx_db_database()
        self.host = PropConfig().get_influx_db_host()
        self.port=PropConfig().get_influx_db_port()
        self.influxDB = None

    # 连接时序数据库；获得InfluxDB
    def influx_db_build(self):
        if self.influxDB is None:
            self.influxDB = InfluxDBClient(host=self.host, port=self.port, username=self.username,password=self.password)
            self.influxDB.create_database(self.database)
        return self.influxDB

     # 设置数据保存策略 defalut 策略名 /database 数据库名/ 30d 数据保存时限30天/ 1 副本个数为1/ 结尾DEFAULT
     # 表示 设为默认的策略
    def create_retention_policy(self):
        command = "CREATE RETENTION POLICY \"default\" ON \""+self.database+"\" DURATION 7200d REPLICATION 1 DEFAULT"
        print(self.query(command))

    # 查询
    def query(self,command):
        if self.influxDB is None:
            self.influxDB = InfluxDBClient(host=self.host,port=self.port,username=self.username,password=self.password)
        return self.influxDB.query(query=command,database=self.database)

    # 插入
    # @param measurement 表
    # @param tags 标签
    # @param fields 字段

    # 插入
    # @param batchPoints 批量插入
    def batch_insert(self,batch_points):
        self.influxDB.write_points(batch_points)

    # 删除
    # @param command 删除语句
    # @return 返回错误信息
    def delete_measurement_data(self,command):
        result = self.influxDB.query(query=command,database=self.database)
        return result['error']

    # 创建数据库
    # @param dbname
    def create_db(self,dbname):
        self.influxDB.create_database(dbname)

    # 删除数据库
    # @param dbname
    def delete_db(self,dbname):
        self.influxDB.drop_database(dbname)
