"""
# @Author  : GengChuhan
# @Time    : 2023/9/12 15:49
# @Function: 
# @Description:
"""

class PropConfig:

    def __init__(self):
        self.properties= {
            "influxDb.url": "http://192.168.99.34:8086",
            "influxDb.username": "root",
            "influxDb.password": "root",
            "influxDb.host": "192.168.99.34",
            "influxDb.port": 8086,
            "influxDb.database": "stec_monitor_rmgc",
            "kafka.bootstrapServers": "192.168.99.34: 9092",
            "kafka.source.topics": "flink-cdc-mysql",
            "kafka.groupId": "jialiuEmergency",
            "mysql.jdbc.url": "jdbc:mysql://192.168.99.22:9306/stec-jialiu?autoReconnect=true&useUnicode=true&characterEncoding=utf-8&zeroDateTimeBehavior=convertToNull&useSSL=false",
            "mysql.username": "cjxxtest",
            "mysql.password": "Suit@4you",
            "mysql.driver": "com.mysql.cj.jdbc.Driver",
            "mysql.host": "192.168.99.22",
            "mysql.port": 9306,
            "mysql.database":"stec-jialiu"
        }

    def get_influx_db_url(self):
        return self.properties["influxDb.url"]

    def get_influx_db_username(self):
        return self.properties["influxDb.username"]

    def get_influx_db_password(self):
        return self.properties["influxDb.password"]

    def get_influx_db_host(self):
        return self.properties["influxDb.host"]

    def get_influx_db_port(self):
        return self.properties["influxDb.port"]

    def get_influx_db_database(self):
        return self.properties["influxDb.database"]

    def get_kafka_bootstrap_servers(self):
        return self.properties["kafka.bootstrapServers"]

    def get_kafka_source_topics(self):
        return self.properties["kafka.source.topics"]

    def get_kafka_group_id(self):
        return self.properties["kafka.groupId"]

    def get_jdbc_url(self):
        return self.properties["mysql.jdbc.url"]

    def get_mysql_user_name(self):
        return self.properties["mysql.username"]

    def get_mysql_password(self):
        return self.properties["mysql.password"]

    def get_mysql_driver(self):
        return self.properties["mysql.driver"]

    def get_mysql_host(self):
        return self.properties["mysql.host"]

    def get_mysql_port(self):
        return self.properties["mysql.port"]

    def get_mysql_database(self):
        return self.properties["mysql.database"]
